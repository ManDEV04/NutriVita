@extends('adminlte::page')

@section('title', 'Dashboard | NutriAdmin')


{{-- =========================================================
     CONTENT HEADER
     ========================================================= --}}
@section('content_header')

    @include('dashboard.partials.header')

@stop


{{-- =========================================================
     DASHBOARD CONTENT
     ========================================================= --}}
@section('content')

    @php
        /*
        |--------------------------------------------------------------------------
        | Valores predeterminados
        |--------------------------------------------------------------------------
        | Se mantienen temporalmente aquí para no alterar
        | la lógica actual del dashboard.
        |
        | Posteriormente podemos mover esta lógica al
        | DashboardController.
        */

        $totalPatients = $totalPatients ?? 0;

        $activePatients = $activePatients ?? 0;

        $inactivePatients = max(
            $totalPatients - $activePatients,
            0
        );

        $activePercentage = $totalPatients > 0
            ? round(($activePatients / $totalPatients) * 100)
            : 0;


        $todayAppointmentsCount =
            $todayAppointmentsCount ?? 0;

        $monthAppointments =
            $monthAppointments ?? 0;

        $monthIncome =
            $monthIncome ?? 0;

        $completedAppointments =
            $completedAppointments ?? 0;


        /*
        |--------------------------------------------------------------------------
        | Datos de gráficos
        |--------------------------------------------------------------------------
        */

        $patientChartLabels =
            $patientChartLabels ??
            ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'];

        $patientChartData =
            $patientChartData ??
            [0, 0, 0, 0, 0, $totalPatients];


        $appointmentChartLabels =
            $appointmentChartLabels ??
            ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

        $appointmentChartData =
            $appointmentChartData ??
            [0, 0, 0, 0, 0, 0, $todayAppointmentsCount];


        $incomeChartLabels =
            $incomeChartLabels ??
            ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'];

        $incomeChartData =
            $incomeChartData ??
            [0, 0, 0, 0, 0, $monthIncome];


        /*
        |--------------------------------------------------------------------------
        | Crecimiento
        |--------------------------------------------------------------------------
        */

        $patientGrowth =
            $patientGrowth ?? 0;

        $appointmentGrowth =
            $appointmentGrowth ?? 0;

        $incomeGrowth =
            $incomeGrowth ?? 0;
    @endphp


    {{-- =====================================================
         DECORACIÓN GENERAL
         ===================================================== --}}
    <div class="dashboard-background">

        <div class="dashboard-background__blob dashboard-background__blob--one"></div>
        <div class="dashboard-background__blob dashboard-background__blob--two"></div>


        {{-- =================================================
             HERO
             ================================================= --}}
        @include('dashboard.partials.hero')


        {{-- =================================================
             MÉTRICAS PRINCIPALES
             ================================================= --}}
        @include('dashboard.partials.metrics')


        {{-- =================================================
             GRÁFICAS
             ================================================= --}}
        @include('dashboard.partials.charts')


        {{-- =================================================
             RESUMEN
             ================================================= --}}
        @include('dashboard.partials.summary')


        {{-- =================================================
             ACCIONES RÁPIDAS
             ================================================= --}}
        @include('dashboard.partials.quick-actions')


        {{-- =================================================
             FOOTER
             ================================================= --}}
        @include('dashboard.partials.footer')

    </div>

@stop